# Hacking Material Design for Bootstrap

This project makes use of Gulp to build all our source codes.

You can get a full list of available commands running:

```
npm run gulp -- --tasks
```

Then, simply run:

```
npm run gulp dist:default // or any other task name
```

To trigger the relative task and run it.
