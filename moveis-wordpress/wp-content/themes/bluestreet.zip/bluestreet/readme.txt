BlueStreet is a Business WordPress Theme that contains a lot of features for customizing your website as you need. Since, this theme is the child theme of WallStreet WordPress Theme, so, you can make use of all the features that are present in the parent theme itself. Already thousands of users loving this theme because it is designed for multiple businesses like corporates, firms, law firms, digital media agency, architecture firm, personal, portfolio and freelancer's website. There is no separate pro version of BlueStreet Theme, you will get all the functionality in the premium version of WallStreet Theme. In the premium version you will get 2 color skins Lite and Dark, 10 predefined color schemes, feature for creating your custom color scheme, an eye-catching Slider, Services, Testimonial’s, Portfolio, Clients/ Sponsors, Blog Layouts, Layout Manager and Latest News. You will find various page templates  like About, Service, Portfolio, Blog and Contact Us. The theme has supports for popular plugins like WPML, Polylang and JetPack Gallery Extensions. Just navigate to Appearance / Customize to start customizing. Both the lite and premium version of WallStreet theme comes with various locales. Check premium version theme demo at http://webriti.com/demo/wp/wallstreet

=== Description ===
In this version you will get the theme Blue color variant. Couple of templates added which is not found in the parent Wallstreet theme.

=== Support ===
For any ideas, support and feedback you can access the theme forum.

== Version ==
= 1.2.4 =
1. Fixed Cf7 styling issue.

= 1.2.3 =
1. Theme URI & Author URI Updated.

= 1.2.2 =
1. String translated in customizer color setting.

= 1.2.1 =
1. Update TGM-Plugin.

= 1.2.0 =
1. Changed duplicate strings.

= 1.1.9 =
1. Update theme description.

= 1.1.8 =
1. Updated String.

= 1.1.7 =
1. Update Theme Description.

= 1.1.6 =
1. Added Spanish Locale

= 1.1.5 =
1. Update Theme Description.
2. Update Theme Tags.

= 1.1.4 =
1. Added spanish language translations files.

= 1.1.3 =
1. Update Default.css File
2. Add Theme Color Variation :- Dark & Lite.

= 1.1.2 =
1. Resolved Theme URI issue.
2. Fix styling issue.

= 1.1.1 =
1. Added Prefix in the script name handlers
2. Loaded Text Domain

1.1
1. Updated theme description 
2. Updated TGM to 2.5.2


1.0 Released